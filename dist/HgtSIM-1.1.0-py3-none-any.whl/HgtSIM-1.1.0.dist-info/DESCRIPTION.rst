

HgtSIM: a simulator for horizontal gene transfer (HGT) in microbial communities

Weizhi Song (songwz03@gmail.com)

The Centre for Marine Bio-Innovation (CMB), 
University of New South Wales, Sydney, Australia

Release history:

1.1.0 (2019-01-06):
HgtSIM can be installed with "pip install HgtSIM" now.

1.0.1 (2018-04-06):
combined the '-mixed', '-mini' and '-maxi' options to '-mixed min-max'.

1.0.0 (2017-09-16):
support for draft genome.
support for dynamic flanking sequences.
support for the 'mixed' mode.
support for the 'keep_cds' option.



